## Folder Structure

Collection of scripts and templates to help customers setup accounts for our "Discover" product.